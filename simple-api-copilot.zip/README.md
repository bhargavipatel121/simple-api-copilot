# Simple API with File Upload

This is a basic Express.js API project that supports file upload using multer.

## How to Run

1. Clone the repo:
   ```bash
   git clone <your-repo-url>
   cd simple-api-copilot
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Start the server:
   ```bash
   node index.js
   ```

Server runs on `http://localhost:3000`